# gopher-json [![GoDoc](https://godoc.org/layeh.com/gopher-json?status.svg)](https://godoc.org/layeh.com/gopher-json)

Package json is a simple JSON encoder/decoder for [gopher-lua](https://github.com/yuin/gopher-lua).

## License

Public domain.
