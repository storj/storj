// +build solaris
// +build !appengine

package pb

const sysIoctl = 54
